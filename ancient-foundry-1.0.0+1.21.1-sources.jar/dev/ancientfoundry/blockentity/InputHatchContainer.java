package dev.ancientfoundry.blockentity;

import net.minecraft.class_1278;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import org.jetbrains.annotations.Nullable;

/**
 * What a hopper sees when it points at an input hatch: the controller's rock, soul and fuel
 * slots, insert-only. Each item type goes to its own slot, so one hatch can take all three.
 */
final class InputHatchContainer implements class_1278 {
	private static final int[] SLOTS = {
			FoundryControllerBlockEntity.SLOT_ROCK,
			FoundryControllerBlockEntity.SLOT_SOUL,
			FoundryControllerBlockEntity.SLOT_FUEL
	};

	private final FoundryControllerBlockEntity controller;

	InputHatchContainer(FoundryControllerBlockEntity controller) {
		this.controller = controller;
	}

	@Override
	public int[] method_5494(class_2350 side) {
		return SLOTS;
	}

	@Override
	public boolean method_5492(int slot, class_1799 stack, @Nullable class_2350 direction) {
		return controller.isFormed() && FoundryControllerBlockEntity.isValidForSlot(slot, stack);
	}

	@Override
	public boolean method_5493(int slot, class_1799 stack, class_2350 direction) {
		return false;
	}

	@Override
	public int method_5439() {
		return SLOTS.length;
	}

	@Override
	public boolean method_5442() {
		for (int slot : SLOTS) {
			if (!controller.method_5438(slot).method_7960()) {
				return false;
			}
		}

		return true;
	}

	@Override
	public class_1799 method_5438(int slot) {
		return controller.method_5438(slot);
	}

	@Override
	public class_1799 method_5434(int slot, int amount) {
		return controller.method_5434(slot, amount);
	}

	@Override
	public class_1799 method_5441(int slot) {
		return controller.method_5441(slot);
	}

	@Override
	public void method_5447(int slot, class_1799 stack) {
		controller.method_5447(slot, stack);
	}

	@Override
	public boolean method_5437(int slot, class_1799 stack) {
		return FoundryControllerBlockEntity.isValidForSlot(slot, stack);
	}

	@Override
	public void method_5431() {
		controller.method_5431();
	}

	@Override
	public boolean method_5443(class_1657 player) {
		return false;
	}

	@Override
	public void method_5448() {
		// The hatch owns nothing; clearing it must not wipe the controller.
	}
}
