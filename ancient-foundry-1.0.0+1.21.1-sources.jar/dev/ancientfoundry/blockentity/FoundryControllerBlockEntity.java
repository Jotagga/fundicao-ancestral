package dev.ancientfoundry.blockentity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import dev.ancientfoundry.AncientFoundry;
import dev.ancientfoundry.block.FoundryControllerBlock;
import dev.ancientfoundry.config.FoundryConfig;
import dev.ancientfoundry.logic.FoundryCore;
import dev.ancientfoundry.menu.FoundryMenu;
import dev.ancientfoundry.multiblock.FoundryStructure;
import dev.ancientfoundry.registry.ModBlockEntities;
import dev.ancientfoundry.registry.ModBlocks;
import dev.ancientfoundry.registry.ModTags;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_124;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1278;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2398;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2609;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3908;
import net.minecraft.class_3913;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import org.jetbrains.annotations.Nullable;

/**
 * Runs the Ancient Foundry: keeps the structure checked, feeds {@link FoundryCore} from its
 * inventory and pushes results out through the output hatches.
 */
public class FoundryControllerBlockEntity extends class_2586 implements class_1278, class_3908 {
	public static final int SLOT_ROCK = 0;
	public static final int SLOT_SOUL = 1;
	public static final int SLOT_FUEL = 2;
	public static final int SLOT_OUTPUT = 3;
	public static final int SLOT_BYPRODUCT = 4;
	public static final int SLOT_COUNT = 5;

	/** Synced values, see {@link #dataAccess}. */
	public static final int DATA_HEAT_PERMILLE = 0;
	public static final int DATA_WORK_HEAT_PERMILLE = 1;
	public static final int DATA_TEMPERATURE = 2;
	public static final int DATA_BURN_PERMILLE = 3;
	public static final int DATA_PROGRESS_PERMILLE = 4;
	public static final int DATA_WINDOW_CYCLE = 5;
	public static final int DATA_WINDOW_SIZE = 6;
	public static final int DATA_STATUS = 7;
	public static final int DATA_WINDOW_SCRAP_FOUND = 8;
	public static final int DATA_TOTAL_SCRAPS_LOW = 9;
	public static final int DATA_TOTAL_SCRAPS_HIGH = 10;
	public static final int DATA_ACTIVE_MINUTES_LOW = 11;
	public static final int DATA_ACTIVE_MINUTES_HIGH = 12;
	public static final int DATA_COUNT = 13;

	/** Temperature shown to the player when the foundry is exactly at working heat. */
	public static final int WORK_TEMPERATURE_CELSIUS = 1200;

	private static final int VALIDATE_INTERVAL = 20;
	private static final int EJECT_INTERVAL = 10;
	private static final int[] ALL_SLOTS = {SLOT_ROCK, SLOT_SOUL, SLOT_FUEL, SLOT_OUTPUT, SLOT_BYPRODUCT};
	private static final int[] RESULT_SLOTS = {SLOT_OUTPUT, SLOT_BYPRODUCT};

	private final class_2371<class_1799> items = class_2371.method_10213(SLOT_COUNT, class_1799.field_8037);
	private final FoundryCore core = new FoundryCore(FoundryConfig.get().toSettings());
	private final CoreHost host = new CoreHost();
	private final class_1278 inputProxy = new InputHatchContainer(this);

	private boolean formed;
	private final Set<class_2338> inputHatches = new HashSet<>();
	private final List<class_2338> outputHatches = new ArrayList<>();
	@Nullable
	private class_2338 ventPos;
	@Nullable
	private FoundryStructure.Result lastResult;
	private int tickCounter;

	/**
	 * Values the open screen needs. The vanilla packet carries each one as a 16-bit number, so
	 * everything is either scaled to 0..1000 or split into 15-bit halves.
	 */
	private final class_3913 dataAccess = new class_3913() {
		@Override
		public int method_17390(int index) {
			FoundryCore.Settings settings = core.settings();
			long activeMinutes = core.activeTicks() / 1200L;

			return switch (index) {
				case DATA_HEAT_PERMILLE -> permille(core.heat(), settings.maxHeat());
				case DATA_WORK_HEAT_PERMILLE -> permille(settings.workHeat(), settings.maxHeat());
				case DATA_TEMPERATURE -> (int) Math.min(30_000L, (long) core.heat() * WORK_TEMPERATURE_CELSIUS / settings.workHeat());
				case DATA_BURN_PERMILLE -> permille(core.burnTime(), core.burnTotal());
				case DATA_PROGRESS_PERMILLE -> permille(core.progress(), settings.cycleTicks());
				case DATA_WINDOW_CYCLE -> Math.min(30_000, core.windowCycle());
				case DATA_WINDOW_SIZE -> Math.min(30_000, settings.cyclesPerScrap());
				case DATA_STATUS -> formed ? core.status().ordinal() : FoundryCore.Status.UNFORMED.ordinal();
				case DATA_WINDOW_SCRAP_FOUND -> core.windowScrapFound() ? 1 : 0;
				case DATA_TOTAL_SCRAPS_LOW -> (int) (core.totalScraps() & 0x7FFF);
				case DATA_TOTAL_SCRAPS_HIGH -> (int) ((core.totalScraps() >> 15) & 0x7FFF);
				case DATA_ACTIVE_MINUTES_LOW -> (int) (activeMinutes & 0x7FFF);
				case DATA_ACTIVE_MINUTES_HIGH -> (int) ((activeMinutes >> 15) & 0x7FFF);
				default -> 0;
			};
		}

		@Override
		public void method_17391(int index, int value) {
			// Server-side values are computed, never set from outside.
		}

		@Override
		public int method_17389() {
			return DATA_COUNT;
		}
	};

	public FoundryControllerBlockEntity(class_2338 pos, class_2680 state) {
		super(ModBlockEntities.FOUNDRY_CONTROLLER, pos, state);
	}

	private static int permille(long value, long max) {
		if (max <= 0L) {
			return 0;
		}

		return (int) Math.max(0L, Math.min(1000L, value * 1000L / max));
	}

	// ------------------------------------------------------------------ ticking

	public static void serverTick(class_1937 level, class_2338 pos, class_2680 state, FoundryControllerBlockEntity controller) {
		if (level instanceof class_3218 serverLevel) {
			controller.tickServer(serverLevel, pos);
		}
	}

	private void tickServer(class_3218 level, class_2338 pos) {
		if (tickCounter % VALIDATE_INTERVAL == 0 || lastResult == null) {
			revalidate(level);
		}

		tickCounter++;

		boolean paused = level.method_49803(pos);
		FoundryCore.Status status = core.tick(host, formed, paused);

		boolean lit = formed && (status == FoundryCore.Status.WORKING || status == FoundryCore.Status.HEATING);
		class_2680 state = this.method_11010();

		if (state.method_11654(FoundryControllerBlock.LIT) != lit || state.method_11654(FoundryControllerBlock.FORMED) != formed) {
			level.method_8652(pos, state.method_11657(FoundryControllerBlock.LIT, lit).method_11657(FoundryControllerBlock.FORMED, formed), 3);
		}

		if (formed && tickCounter % EJECT_INTERVAL == 0) {
			ejectResults(level);
		}

		if (status == FoundryCore.Status.WORKING && ventPos != null && tickCounter % 8 == 0) {
			level.method_14199(class_2398.field_17430,
					ventPos.method_10263() + 0.5, ventPos.method_10264() + 1.1, ventPos.method_10260() + 0.5, 1, 0.12, 0.0, 0.12, 0.01);
		}

		if (core.isActive()) {
			// Heat and progress change every tick; keep the chunk marked for saving without
			// triggering comparator updates the way setChanged() would.
			level.method_8524(pos);
		}
	}

	/** Re-checks the structure right away. Skipped while part of it sits in an unloaded chunk. */
	public void revalidate(class_1937 level) {
		class_2338 pos = this.method_11016();
		class_2350 facing = this.method_11010().method_11654(FoundryControllerBlock.FACING);

		if (!FoundryStructure.isAreaLoaded(level, pos, facing)) {
			return;
		}

		FoundryStructure.Result result = FoundryStructure.validate(level, pos, facing);
		boolean wasFormed = formed;

		lastResult = result;
		formed = result.formed();
		inputHatches.clear();
		outputHatches.clear();
		ventPos = result.vent();

		if (formed) {
			inputHatches.addAll(result.inputHatches());
			outputHatches.addAll(result.outputHatches());
		}

		if (wasFormed != formed) {
			this.method_5431();
		}
	}

	private void ejectResults(class_3218 level) {
		if (outputHatches.isEmpty() || (items.get(SLOT_OUTPUT).method_7960() && items.get(SLOT_BYPRODUCT).method_7960())) {
			return;
		}

		for (class_2338 hatch : outputHatches) {
			for (class_2350 direction : class_2350.values()) {
				class_2338 target = hatch.method_10093(direction);

				if (isFoundryBlock(level.method_8320(target))) {
					continue;
				}

				Storage<ItemVariant> storage = ItemStorage.SIDED.find(level, target, direction.method_10153());

				if (storage == null || !storage.supportsInsertion()) {
					continue;
				}

				for (int slot : RESULT_SLOTS) {
					class_1799 stack = items.get(slot);

					if (stack.method_7960()) {
						continue;
					}

					try (Transaction transaction = Transaction.openOuter()) {
						long moved = storage.insert(ItemVariant.of(stack), stack.method_7947(), transaction);

						if (moved > 0) {
							transaction.commit();
							stack.method_7934((int) moved);
							this.method_5431();
						}
					}
				}
			}
		}
	}

	private static boolean isFoundryBlock(class_2680 state) {
		return class_7923.field_41175.method_10221(state.method_26204()).method_12836().equals(AncientFoundry.MOD_ID);
	}

	// ------------------------------------------------------------------ interaction

	/** Right-click: opens the screen, or tells the player which block is still missing. */
	public void onUse(class_1657 player) {
		class_1937 level = this.method_10997();

		if (level == null) {
			return;
		}

		revalidate(level);

		if (formed) {
			player.method_17355(this);
			return;
		}

		FoundryStructure.Result result = lastResult;

		if (result == null || result.errorPos() == null || result.errorPart() == null) {
			player.method_7353(class_2561.method_43471("message.ancient_foundry.not_loaded").method_27692(class_124.field_1061), false);
			return;
		}

		class_2338 error = result.errorPos();
		class_2561 part = class_2561.method_43471("message.ancient_foundry.part." + result.errorPart().name().toLowerCase(Locale.ROOT))
				.method_27692(class_124.field_1065);
		class_2561 layer = class_2561.method_43471("message.ancient_foundry.layer." + result.errorLayer());
		player.method_7353(class_2561.method_43469("message.ancient_foundry.incomplete",
				part, error.method_10263(), error.method_10264(), error.method_10260(), layer).method_27692(class_124.field_1061), false);

		if (level instanceof class_3218 serverLevel) {
			serverLevel.method_14199(class_2398.field_11207,
					error.method_10263() + 0.5, error.method_10264() + 0.5, error.method_10260() + 0.5, 24, 0.35, 0.35, 0.35, 0.0);
		}
	}

	// ------------------------------------------------------------------ queries

	public boolean isFormed() {
		return formed;
	}

	public FoundryCore core() {
		return core;
	}

	@Nullable
	public FoundryStructure.Result lastResult() {
		return lastResult;
	}

	public boolean ownsInputHatch(class_2338 pos) {
		return formed && inputHatches.contains(pos);
	}

	public List<class_2338> outputHatches() {
		return List.copyOf(outputHatches);
	}

	/** The container hoppers see through an input hatch. Always the same instance. */
	public class_1278 getInputProxy() {
		return inputProxy;
	}

	/**
	 * Finds the formed foundry an input hatch belongs to, or null.
	 *
	 * <p>A hatch sits in a wall or in the roof, so its controller is at most 4 blocks away
	 * sideways and up to 2 blocks below.
	 */
	@Nullable
	public static FoundryControllerBlockEntity findForInputHatch(class_1936 level, class_2338 hatch) {
		class_2338.class_2339 cursor = new class_2338.class_2339();

		for (int dx = -4; dx <= 4; dx++) {
			for (int dz = -4; dz <= 4; dz++) {
				if (!level.method_8393((hatch.method_10263() + dx) >> 4, (hatch.method_10260() + dz) >> 4)) {
					continue;
				}

				for (int dy = 0; dy >= -2; dy--) {
					cursor.method_10103(hatch.method_10263() + dx, hatch.method_10264() + dy, hatch.method_10260() + dz);

					if (level.method_8320(cursor).method_27852(ModBlocks.FOUNDRY_CONTROLLER)
							&& level.method_8321(cursor) instanceof FoundryControllerBlockEntity controller
							&& controller.ownsInputHatch(hatch)) {
						return controller;
					}
				}
			}
		}

		return null;
	}

	// ------------------------------------------------------------------ core host

	private final class CoreHost implements FoundryCore.Host {
		@Override
		public boolean hasIngredients() {
			return !items.get(SLOT_ROCK).method_7960() && !items.get(SLOT_SOUL).method_7960();
		}

		@Override
		public boolean hasOutputSpace() {
			class_1799 output = items.get(SLOT_OUTPUT);
			return output.method_7960() || (output.method_31574(class_1802.field_22021) && output.method_7947() < output.method_7914());
		}

		@Override
		public int takeFuel() {
			class_1799 fuel = items.get(SLOT_FUEL);

			if (fuel.method_7960()) {
				return 0;
			}

			class_1792 item = fuel.method_7909();
			int burnTime = class_2609.method_11196().getOrDefault(item, 0);

			if (burnTime <= 0) {
				return 0;
			}

			fuel.method_7934(1);

			if (item.method_7857()) {
				class_1792 remainder = item.method_7858();

				if (remainder != null) {
					addByproduct(new class_1799(remainder));
				}
			}

			method_5431();
			return (int) Math.max(1L, (long) burnTime * FoundryConfig.get().fuelEfficiencyPercent / 100L);
		}

		@Override
		public void consumeIngredients() {
			items.get(SLOT_ROCK).method_7934(1);
			items.get(SLOT_SOUL).method_7934(1);
			method_5431();
		}

		@Override
		public void produceScrap() {
			class_1799 output = items.get(SLOT_OUTPUT);

			if (output.method_7960()) {
				items.set(SLOT_OUTPUT, new class_1799(class_1802.field_22021));
			} else {
				output.method_7933(1);
			}

			method_5431();

			if (method_10997() instanceof class_3218 serverLevel) {
				class_2338 pos = method_11016();
				serverLevel.method_8396(null, pos, class_3417.field_21891, class_3419.field_15245, 1.0F, 0.7F);
				serverLevel.method_8396(null, pos, class_3417.field_14627, class_3419.field_15245, 0.6F, 0.6F);

				class_2338 burst = ventPos != null ? ventPos.method_10084() : pos.method_10084();
				serverLevel.method_14199(class_2398.field_22246,
						burst.method_10263() + 0.5, burst.method_10264() + 0.2, burst.method_10260() + 0.5, 30, 0.2, 0.3, 0.2, 0.03);
			}
		}

		@Override
		public int nextInt(int bound) {
			class_1937 level = method_10997();
			return level != null ? level.method_8409().method_43048(bound) : (int) (Math.random() * bound);
		}
	}

	/** Puts a leftover (an empty bucket, say) in the by-product slot, or drops it in front of the controller. */
	private void addByproduct(class_1799 stack) {
		class_1799 current = items.get(SLOT_BYPRODUCT);

		if (current.method_7960()) {
			items.set(SLOT_BYPRODUCT, stack);
			return;
		}

		if (class_1799.method_31577(current, stack) && current.method_7947() + stack.method_7947() <= current.method_7914()) {
			current.method_7933(stack.method_7947());
			return;
		}

		class_1937 level = this.method_10997();

		if (level != null) {
			class_2338 front = this.method_11016().method_10093(this.method_11010().method_11654(FoundryControllerBlock.FACING));
			class_1264.method_5449(level, front.method_10263() + 0.5, front.method_10264() + 0.5, front.method_10260() + 0.5, stack);
		}
	}

	// ------------------------------------------------------------------ container

	/** Which items a slot accepts. Result slots accept nothing from outside. */
	public static boolean isValidForSlot(int slot, class_1799 stack) {
		return switch (slot) {
			case SLOT_ROCK -> stack.method_31573(ModTags.FOUNDRY_ROCK);
			case SLOT_SOUL -> stack.method_31573(ModTags.FOUNDRY_SOUL);
			case SLOT_FUEL -> class_2609.method_11195(stack);
			default -> false;
		};
	}

	@Override
	public int method_5439() {
		return SLOT_COUNT;
	}

	@Override
	public boolean method_5442() {
		for (class_1799 stack : items) {
			if (!stack.method_7960()) {
				return false;
			}
		}

		return true;
	}

	@Override
	public class_1799 method_5438(int slot) {
		return items.get(slot);
	}

	@Override
	public class_1799 method_5434(int slot, int amount) {
		class_1799 removed = class_1262.method_5430(items, slot, amount);

		if (!removed.method_7960()) {
			this.method_5431();
		}

		return removed;
	}

	@Override
	public class_1799 method_5441(int slot) {
		return class_1262.method_5428(items, slot);
	}

	@Override
	public void method_5447(int slot, class_1799 stack) {
		items.set(slot, stack);
		stack.method_58408(this.method_58350(stack));
		this.method_5431();
	}

	@Override
	public boolean method_5443(class_1657 player) {
		return class_1263.method_49105(this, player);
	}

	@Override
	public boolean method_5437(int slot, class_1799 stack) {
		return isValidForSlot(slot, stack);
	}

	@Override
	public void method_5448() {
		items.clear();
		this.method_5431();
	}

	@Override
	public int[] method_5494(class_2350 side) {
		return ALL_SLOTS;
	}

	@Override
	public boolean method_5492(int slot, class_1799 stack, @Nullable class_2350 direction) {
		return isValidForSlot(slot, stack);
	}

	@Override
	public boolean method_5493(int slot, class_1799 stack, class_2350 direction) {
		return slot == SLOT_OUTPUT || slot == SLOT_BYPRODUCT;
	}

	// ------------------------------------------------------------------ menu

	@Override
	public class_2561 method_5476() {
		return class_2561.method_43471("container.ancient_foundry.foundry");
	}

	@Override
	public class_1703 createMenu(int containerId, class_1661 playerInventory, class_1657 player) {
		return new FoundryMenu(containerId, playerInventory, this, dataAccess);
	}

	public class_3913 dataAccess() {
		return dataAccess;
	}

	// ------------------------------------------------------------------ saving

	@Override
	protected void method_11007(class_2487 tag, class_7225.class_7874 registries) {
		super.method_11007(tag, registries);
		class_1262.method_5426(tag, items, registries);
		tag.method_10556("Formed", formed);
		tag.method_10569("Heat", core.heat());
		tag.method_10569("BurnTime", core.burnTime());
		tag.method_10569("BurnTotal", core.burnTotal());
		tag.method_10569("Progress", core.progress());
		tag.method_10569("WindowCycle", core.windowCycle());
		tag.method_10569("WinningCycle", core.winningCycle());
		tag.method_10544("TotalScraps", core.totalScraps());
		tag.method_10544("ActiveTicks", core.activeTicks());
	}

	@Override
	protected void method_11014(class_2487 tag, class_7225.class_7874 registries) {
		super.method_11014(tag, registries);
		items.clear();
		class_1262.method_5429(tag, items, registries);
		formed = tag.method_10577("Formed");
		core.restore(tag.method_10550("Heat"), tag.method_10550("BurnTime"), tag.method_10550("BurnTotal"), tag.method_10550("Progress"),
				tag.method_10550("WindowCycle"), tag.method_10545("WinningCycle") ? tag.method_10550("WinningCycle") : -1,
				tag.method_10537("TotalScraps"), tag.method_10537("ActiveTicks"));
	}
}
