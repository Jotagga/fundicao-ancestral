package dev.ancientfoundry.item;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2248;
import net.minecraft.class_2561;

/** A block item with a one-line hint under its name, read from {@code <description id>.tooltip}. */
public class TooltipBlockItem extends class_1747 {
	public TooltipBlockItem(class_2248 block, class_1792.class_1793 properties) {
		super(block, properties);
	}

	@Override
	public void method_7851(class_1799 stack, class_1792.class_9635 context, List<class_2561> tooltip, class_1836 flag) {
		super.method_7851(stack, context, tooltip, flag);
		tooltip.add(class_2561.method_43471(this.method_7876() + ".tooltip").method_27692(class_124.field_1080));
	}
}
