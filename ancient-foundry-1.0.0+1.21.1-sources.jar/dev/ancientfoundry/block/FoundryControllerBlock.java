package dev.ancientfoundry.block;

import com.mojang.serialization.MapCodec;
import dev.ancientfoundry.blockentity.FoundryControllerBlockEntity;
import dev.ancientfoundry.registry.ModBlockEntities;
import net.minecraft.class_1264;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2398;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

/**
 * The foundry's control block. It sits in the middle of the front wall, checks the structure
 * behind it and runs the process.
 */
public class FoundryControllerBlock extends class_2237 {
	public static final MapCodec<FoundryControllerBlock> CODEC = method_54094(FoundryControllerBlock::new);

	public static final class_2753 FACING = class_2383.field_11177;
	/** True while the fire is on (heating up or working). */
	public static final class_2746 LIT = class_2741.field_12548;
	/** True while the multiblock behind the controller is complete. */
	public static final class_2746 FORMED = class_2746.method_11825("formed");

	public FoundryControllerBlock(class_4970.class_2251 properties) {
		super(properties);
		this.method_9590(this.field_10647.method_11664()
				.method_11657(FACING, class_2350.field_11043)
				.method_11657(LIT, false)
				.method_11657(FORMED, false));
	}

	@Override
	public MapCodec<? extends class_2237> method_53969() {
		return field_46280;
	}

	@Override
	protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
		builder.method_11667(FACING, LIT, FORMED);
	}

	@Override
	public class_2680 method_9605(class_1750 context) {
		return this.method_9564().method_11657(FACING, context.method_8042().method_10153());
	}

	@Override
	public class_2464 method_9604(class_2680 state) {
		return class_2464.field_11458;
	}

	@Override
	public class_2586 method_10123(class_2338 pos, class_2680 state) {
		return new FoundryControllerBlockEntity(pos, state);
	}

	@Override
	@Nullable
	public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> type) {
		return level.field_9236 ? null : method_31618(type, ModBlockEntities.FOUNDRY_CONTROLLER, FoundryControllerBlockEntity::serverTick);
	}

	@Override
	public class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
		if (level.field_9236) {
			return class_1269.field_5812;
		}

		if (level.method_8321(pos) instanceof FoundryControllerBlockEntity controller) {
			controller.onUse(player);
		}

		return class_1269.field_21466;
	}

	@Override
	public void method_9536(class_2680 state, class_1937 level, class_2338 pos, class_2680 newState, boolean movedByPiston) {
		if (!state.method_27852(newState.method_26204())) {
			if (level.method_8321(pos) instanceof FoundryControllerBlockEntity controller) {
				class_1264.method_5451(level, pos, controller);
				level.method_8455(pos, this);
			}
		}

		super.method_9536(state, level, pos, newState, movedByPiston);
	}

	@Override
	public boolean method_9498(class_2680 state) {
		return true;
	}

	@Override
	public int method_9572(class_2680 state, class_1937 level, class_2338 pos) {
		return class_1703.method_7608(level.method_8321(pos));
	}

	@Override
	public class_2680 method_9598(class_2680 state, class_2470 rotation) {
		return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
	}

	@Override
	public class_2680 method_9569(class_2680 state, class_2415 mirror) {
		return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
	}

	@Override
	public void method_9496(class_2680 state, class_1937 level, class_2338 pos, class_5819 random) {
		if (!state.method_11654(LIT)) {
			return;
		}

		double x = pos.method_10263() + 0.5;
		double y = pos.method_10264();
		double z = pos.method_10260() + 0.5;

		if (random.method_43058() < 0.1) {
			level.method_8486(x, y, z, class_3417.field_17605, class_3419.field_15245, 1.0F, 1.0F, false);
		}

		class_2350 facing = state.method_11654(FACING);
		double spread = random.method_43058() * 0.6 - 0.3;
		double dx = facing.method_10166() == class_2350.class_2351.field_11048 ? facing.method_10148() * 0.52 : spread;
		double dy = random.method_43058() * 4.0 / 16.0 + 0.15;
		double dz = facing.method_10166() == class_2350.class_2351.field_11051 ? facing.method_10165() * 0.52 : spread;
		level.method_8406(class_2398.field_11251, x + dx, y + dy, z + dz, 0.0, 0.0, 0.0);
		level.method_8406(class_2398.field_22246, x + dx, y + dy, z + dz, 0.0, 0.0, 0.0);
	}
}
