package dev.ancientfoundry.block;

import dev.ancientfoundry.blockentity.FoundryControllerBlockEntity;
import net.minecraft.class_1278;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3954;
import net.minecraft.class_4970;
import org.jetbrains.annotations.Nullable;

/**
 * A wall block that lets hoppers, droppers and pipes feed the foundry.
 *
 * <p>The hatch stores nothing itself: while it is part of a formed foundry it exposes the
 * controller's rock, soul and fuel slots. Outside a formed foundry it is not a container at all.
 */
public class InputHatchBlock extends class_2248 implements class_3954 {
	public InputHatchBlock(class_4970.class_2251 properties) {
		super(properties);
	}

	@Override
	@Nullable
	public class_1278 method_17680(class_2680 state, class_1936 level, class_2338 pos) {
		FoundryControllerBlockEntity controller = FoundryControllerBlockEntity.findForInputHatch(level, pos);
		return controller == null ? null : controller.getInputProxy();
	}
}
