package dev.ancientfoundry.block;

import net.minecraft.class_4970;
import net.minecraft.class_8923;

/** Heat-proof window for the foundry walls. Behaves like vanilla glass but drops itself. */
public class FoundryGlassBlock extends class_8923 {
	public FoundryGlassBlock(class_4970.class_2251 properties) {
		super(properties);
	}
}
