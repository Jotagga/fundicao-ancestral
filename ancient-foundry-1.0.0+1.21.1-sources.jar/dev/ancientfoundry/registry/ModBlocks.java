package dev.ancientfoundry.registry;

import dev.ancientfoundry.AncientFoundry;
import dev.ancientfoundry.block.FoundryControllerBlock;
import dev.ancientfoundry.block.FoundryGlassBlock;
import dev.ancientfoundry.block.InputHatchBlock;
import dev.ancientfoundry.item.TooltipBlockItem;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_2766;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

public final class ModBlocks {
	public static final class_2248 FOUNDRY_CASING = register("foundry_casing", new class_2248(machine()));

	public static final class_2248 FOUNDRY_GLASS = register("foundry_glass", new FoundryGlassBlock(
			class_4970.class_2251.method_9637()
					.method_31710(class_3620.field_16009)
					.method_51368(class_2766.field_12645)
					.method_29292()
					.method_9629(2.0F, 9.0F)
					.method_9626(class_2498.field_11537)
					.method_22488()
					.method_26235((state, level, pos, entityType) -> false)
					.method_26236((state, level, pos) -> false)
					.method_26243((state, level, pos) -> false)
					.method_26245((state, level, pos) -> false)));

	public static final class_2248 FOUNDRY_CONTROLLER = register("foundry_controller", new FoundryControllerBlock(
			machine().method_9631(ModBlocks::controllerLight)));

	public static final class_2248 FOUNDRY_INPUT_HATCH = register("foundry_input_hatch", new InputHatchBlock(machine()));

	public static final class_2248 FOUNDRY_OUTPUT_HATCH = register("foundry_output_hatch", new class_2248(machine()));

	public static final class_2248 FOUNDRY_VENT = register("foundry_vent", new class_2248(machine()));

	public static final class_2248 ANCIENT_CORE = register("ancient_core", new class_2248(
			machine().method_31710(class_3620.field_16026).method_9629(5.0F, 1200.0F).method_9631(state -> 10)));

	private ModBlocks() {
	}

	private static class_4970.class_2251 machine() {
		return class_4970.class_2251.method_9637()
				.method_31710(class_3620.field_16009)
				.method_51368(class_2766.field_12653)
				.method_29292()
				.method_9629(3.5F, 9.0F)
				.method_9626(class_2498.field_22150);
	}

	private static int controllerLight(class_2680 state) {
		return state.method_11654(FoundryControllerBlock.LIT) ? 13 : 0;
	}

	private static <T extends class_2248> T register(String name, T block) {
		class_2960 id = AncientFoundry.id(name);
		class_2378.method_10230(class_7923.field_41175, id, block);
		class_2378.method_10230(class_7923.field_41178, id, new TooltipBlockItem(block, new class_1792.class_1793()));
		return block;
	}

	/** Forces class loading, which runs the registrations above. */
	public static void init() {
	}
}
