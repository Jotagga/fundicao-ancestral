package dev.ancientfoundry.registry;

import dev.ancientfoundry.AncientFoundry;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class ModCreativeTab {
	public static final class_5321<class_1761> KEY = class_5321.method_29179(class_7924.field_44688, AncientFoundry.id("main"));

	public static final class_1761 TAB = class_2378.method_39197(class_7923.field_44687, KEY,
			FabricItemGroup.builder()
					.method_47321(class_2561.method_43471("itemGroup.ancient_foundry"))
					.method_47320(() -> new class_1799(ModBlocks.FOUNDRY_CONTROLLER))
					.method_47317((parameters, output) -> {
						output.method_45421(ModBlocks.FOUNDRY_CONTROLLER);
						output.method_45421(ModBlocks.FOUNDRY_CASING);
						output.method_45421(ModBlocks.FOUNDRY_GLASS);
						output.method_45421(ModBlocks.ANCIENT_CORE);
						output.method_45421(ModBlocks.FOUNDRY_VENT);
						output.method_45421(ModBlocks.FOUNDRY_INPUT_HATCH);
						output.method_45421(ModBlocks.FOUNDRY_OUTPUT_HATCH);
					})
					.method_47324());

	private ModCreativeTab() {
	}

	public static void init() {
	}
}
