package dev.ancientfoundry.registry;

import dev.ancientfoundry.AncientFoundry;
import dev.ancientfoundry.blockentity.FoundryControllerBlockEntity;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_7923;

public final class ModBlockEntities {
	public static final class_2591<FoundryControllerBlockEntity> FOUNDRY_CONTROLLER = class_2378.method_10230(
			class_7923.field_41181,
			AncientFoundry.id("foundry_controller"),
			class_2591.class_2592.method_20528(FoundryControllerBlockEntity::new, ModBlocks.FOUNDRY_CONTROLLER).method_11034(null));

	private ModBlockEntities() {
	}

	public static void init() {
	}
}
