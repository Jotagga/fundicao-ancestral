package dev.ancientfoundry.registry;

import dev.ancientfoundry.AncientFoundry;
import net.minecraft.class_1792;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public final class ModTags {
	/** Nether rock the foundry crushes: one per cycle. */
	public static final class_6862<class_1792> FOUNDRY_ROCK = class_6862.method_40092(class_7924.field_41197, AncientFoundry.id("foundry_rock"));

	/** Soul matter the foundry infuses into the rock: one per cycle. */
	public static final class_6862<class_1792> FOUNDRY_SOUL = class_6862.method_40092(class_7924.field_41197, AncientFoundry.id("foundry_soul"));

	private ModTags() {
	}

	public static void init() {
	}
}
