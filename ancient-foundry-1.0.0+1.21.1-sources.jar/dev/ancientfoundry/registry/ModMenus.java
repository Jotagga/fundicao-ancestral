package dev.ancientfoundry.registry;

import dev.ancientfoundry.AncientFoundry;
import dev.ancientfoundry.menu.FoundryMenu;
import net.minecraft.class_2378;
import net.minecraft.class_3917;
import net.minecraft.class_7701;
import net.minecraft.class_7923;

public final class ModMenus {
	public static final class_3917<FoundryMenu> FOUNDRY = class_2378.method_10230(
			class_7923.field_41187,
			AncientFoundry.id("foundry"),
			new class_3917<FoundryMenu>(FoundryMenu::new, class_7701.field_40182));

	private ModMenus() {
	}

	public static void init() {
	}
}
