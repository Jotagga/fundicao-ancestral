package dev.ancientfoundry.client;

import dev.ancientfoundry.registry.ModBlocks;
import dev.ancientfoundry.registry.ModMenus;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.minecraft.class_1921;
import net.minecraft.class_3929;

public final class AncientFoundryClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		class_3929.method_17542(ModMenus.FOUNDRY, FoundryScreen::new);
		BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.FOUNDRY_GLASS, class_1921.method_23583());
	}
}
