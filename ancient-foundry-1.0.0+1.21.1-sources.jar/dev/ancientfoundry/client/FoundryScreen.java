package dev.ancientfoundry.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import dev.ancientfoundry.AncientFoundry;
import dev.ancientfoundry.logic.FoundryCore;
import dev.ancientfoundry.menu.FoundryMenu;

/**
 * Screen of the foundry controller. The background texture is 176x200; the animated pieces
 * (heat column, flame, arrow) sit to the right of it in the same 256x256 sheet.
 */
public class FoundryScreen extends class_465<FoundryMenu> {
	private static final class_2960 TEXTURE = AncientFoundry.id("textures/gui/foundry.png");

	// Heat column.
	private static final int HEAT_X = 12;
	private static final int HEAT_Y = 20;
	private static final int HEAT_WIDTH = 8;
	private static final int HEAT_HEIGHT = 50;
	private static final int HEAT_U = 176;
	private static final int HEAT_V = 0;

	// Flame between the inputs and the fuel slot.
	private static final int FLAME_X = 56;
	private static final int FLAME_Y = 40;
	private static final int FLAME_SIZE = 14;
	private static final int FLAME_U = 176;
	private static final int FLAME_V = 52;

	// Progress arrow.
	private static final int ARROW_X = 92;
	private static final int ARROW_Y = 38;
	private static final int ARROW_WIDTH = 24;
	private static final int ARROW_HEIGHT = 17;
	private static final int ARROW_U = 176;
	private static final int ARROW_V = 68;

	// Read-out panel.
	private static final int PANEL_X = 7;
	private static final int PANEL_Y = 79;
	private static final int PANEL_WIDTH = 162;
	private static final int PANEL_HEIGHT = 25;
	private static final int LINE_1_Y = 83;
	private static final int LINE_2_Y = 93;

	/** Hint shown over each empty machine slot, indexed like the menu's first five slots. */
	private static final String[] SLOT_HINTS = {
			"gui.ancient_foundry.slot.rock",
			"gui.ancient_foundry.slot.soul",
			"gui.ancient_foundry.slot.fuel",
			"gui.ancient_foundry.slot.output",
			"gui.ancient_foundry.slot.byproduct"
	};

	private static final int COLOR_LABEL = 0x404040;
	private static final int COLOR_PANEL_TEXT = 0xD8D8D8;
	private static final int COLOR_GOOD = 0x6BF0E6;
	private static final int COLOR_WARM = 0xFFB347;
	private static final int COLOR_BAD = 0xFF6B6B;
	private static final int COLOR_IDLE = 0xA0A0A0;

	public FoundryScreen(FoundryMenu menu, class_1661 playerInventory, class_2561 title) {
		super(menu, playerInventory, title);
		this.field_2792 = 176;
		this.field_2779 = 200;
		this.field_25270 = this.field_2779 - 94;
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
		super.method_25394(graphics, mouseX, mouseY, partialTick);
		this.method_2380(graphics, mouseX, mouseY);
		this.renderGaugeTooltips(graphics, mouseX, mouseY);
	}

	@Override
	protected void method_2389(class_332 graphics, float partialTick, int mouseX, int mouseY) {
		int left = this.field_2776;
		int top = this.field_2800;
		graphics.method_25302(TEXTURE, left, top, 0, 0, this.field_2792, this.field_2779);

		// Heat column fills from the bottom.
		int heat = scaled(this.field_2797.heatPermille(), HEAT_HEIGHT);

		if (heat > 0) {
			graphics.method_25302(TEXTURE, left + HEAT_X, top + HEAT_Y + HEAT_HEIGHT - heat, HEAT_U, HEAT_V + HEAT_HEIGHT - heat, HEAT_WIDTH, heat);
		}

		// Mark of the working temperature across the column.
		int mark = top + HEAT_Y + HEAT_HEIGHT - scaled(this.field_2797.workHeatPermille(), HEAT_HEIGHT);
		graphics.method_25294(left + HEAT_X - 2, mark, left + HEAT_X + HEAT_WIDTH + 2, mark + 1, 0xFFFFFFFF);

		// Flame shrinks from the top as the fuel item burns away.
		int burn = scaled(this.field_2797.burnPermille(), FLAME_SIZE);

		if (burn > 0) {
			graphics.method_25302(TEXTURE, left + FLAME_X, top + FLAME_Y + FLAME_SIZE - burn, FLAME_U, FLAME_V + FLAME_SIZE - burn, FLAME_SIZE, burn);
		}

		// Arrow fills from the left with the cycle.
		int progress = scaled(this.field_2797.progressPermille(), ARROW_WIDTH);

		if (progress > 0) {
			graphics.method_25302(TEXTURE, left + ARROW_X, top + ARROW_Y, ARROW_U, ARROW_V, progress, ARROW_HEIGHT);
		}
	}

	@Override
	protected void method_2388(class_332 graphics, int mouseX, int mouseY) {
		graphics.method_51439(this.field_22793, this.field_22785, this.field_25267, this.field_25268, COLOR_LABEL, false);
		graphics.method_51439(this.field_22793, this.field_29347, this.field_25269, this.field_25270, COLOR_LABEL, false);

		FoundryCore.Status status = this.field_2797.status();
		class_2561 statusText = class_2561.method_43471("gui.ancient_foundry.status." + status.name().toLowerCase(Locale.ROOT));
		graphics.method_51439(this.field_22793, statusText, PANEL_X + 4, LINE_1_Y, statusColor(status), false);

		class_2561 temperature = class_2561.method_43469("gui.ancient_foundry.temperature", this.field_2797.temperature());
		graphics.method_51439(this.field_22793, temperature, PANEL_X + PANEL_WIDTH - 4 - this.field_22793.method_27525(temperature), LINE_1_Y, COLOR_PANEL_TEXT, false);

		class_2561 window = class_2561.method_43469("gui.ancient_foundry.window", this.field_2797.windowCycle(), this.field_2797.windowSize());
		graphics.method_51439(this.field_22793, window, PANEL_X + 4, LINE_2_Y, COLOR_PANEL_TEXT, false);

		class_2561 total = class_2561.method_43469("gui.ancient_foundry.total", this.field_2797.totalScraps());
		graphics.method_51439(this.field_22793, total, PANEL_X + PANEL_WIDTH - 4 - this.field_22793.method_27525(total), LINE_2_Y, COLOR_PANEL_TEXT, false);
	}

	private void renderGaugeTooltips(class_332 graphics, int mouseX, int mouseY) {
		class_1735 hovered = this.field_2787;

		if (hovered != null && hovered.field_7874 < SLOT_HINTS.length && !hovered.method_7681() && this.field_2797.method_34255().method_7960()) {
			// An empty machine slot explains what it takes.
			graphics.method_51438(this.field_22793, class_2561.method_43471(SLOT_HINTS[hovered.field_7874]), mouseX, mouseY);
		} else if (this.method_2378(HEAT_X - 2, HEAT_Y - 2, HEAT_WIDTH + 4, HEAT_HEIGHT + 4, mouseX, mouseY)) {
			List<class_2561> lines = new ArrayList<>();
			lines.add(class_2561.method_43469("gui.ancient_foundry.tooltip.heat", this.field_2797.temperature()));
			lines.add(class_2561.method_43471("gui.ancient_foundry.tooltip.heat_needed").method_27692(class_124.field_1080));
			graphics.method_51434(this.field_22793, lines, mouseX, mouseY);
		} else if (this.method_2378(ARROW_X, ARROW_Y, ARROW_WIDTH, ARROW_HEIGHT, mouseX, mouseY)) {
			List<class_2561> lines = new ArrayList<>();
			lines.add(class_2561.method_43469("gui.ancient_foundry.tooltip.cycle", this.field_2797.progressPermille() / 10));
			lines.add(class_2561.method_43471("gui.ancient_foundry.tooltip.cycle_cost").method_27692(class_124.field_1080));
			graphics.method_51434(this.field_22793, lines, mouseX, mouseY);
		} else if (this.method_2378(FLAME_X, FLAME_Y, FLAME_SIZE, FLAME_SIZE, mouseX, mouseY)) {
			graphics.method_51438(this.field_22793, class_2561.method_43469("gui.ancient_foundry.tooltip.fuel", this.field_2797.burnPermille() / 10), mouseX, mouseY);
		} else if (this.method_2378(PANEL_X, PANEL_Y, PANEL_WIDTH, PANEL_HEIGHT, mouseX, mouseY)) {
			List<class_2561> lines = new ArrayList<>();
			lines.add(class_2561.method_43469("gui.ancient_foundry.tooltip.window", this.field_2797.windowSize()));
			lines.add(class_2561.method_43471(this.field_2797.windowScrapFound()
					? "gui.ancient_foundry.tooltip.window_found"
					: "gui.ancient_foundry.tooltip.window_pending").method_27692(class_124.field_1080));
			int minutes = this.field_2797.activeMinutes();
			lines.add(class_2561.method_43469("gui.ancient_foundry.tooltip.active", minutes / 60, minutes % 60).method_27692(class_124.field_1080));
			graphics.method_51434(this.field_22793, lines, mouseX, mouseY);
		}
	}

	private static int scaled(int permille, int size) {
		if (permille <= 0) {
			return 0;
		}

		return Math.max(1, Math.min(size, permille * size / 1000));
	}

	private static int statusColor(FoundryCore.Status status) {
		return switch (status) {
			case WORKING -> COLOR_GOOD;
			case HEATING -> COLOR_WARM;
			case PAUSED -> COLOR_IDLE;
			case UNFORMED, NO_INPUT, OUTPUT_FULL, NO_FUEL -> COLOR_BAD;
		};
	}
}
