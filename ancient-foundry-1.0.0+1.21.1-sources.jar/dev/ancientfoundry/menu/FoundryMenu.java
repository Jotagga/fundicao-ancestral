package dev.ancientfoundry.menu;

import dev.ancientfoundry.blockentity.FoundryControllerBlockEntity;
import dev.ancientfoundry.logic.FoundryCore;
import dev.ancientfoundry.registry.ModMenus;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3913;
import net.minecraft.class_3919;

/** The controller's inventory screen: three inputs, two results and the synced gauges. */
public class FoundryMenu extends class_1703 {
	public static final int ROCK_X = 44;
	public static final int ROCK_Y = 20;
	public static final int SOUL_X = 66;
	public static final int SOUL_Y = 20;
	public static final int FUEL_X = 55;
	public static final int FUEL_Y = 57;
	public static final int OUTPUT_X = 128;
	public static final int OUTPUT_Y = 38;
	public static final int BYPRODUCT_X = 152;
	public static final int BYPRODUCT_Y = 38;
	public static final int INVENTORY_X = 8;
	public static final int INVENTORY_Y = 118;
	public static final int HOTBAR_Y = 176;

	private static final int MACHINE_SLOTS = FoundryControllerBlockEntity.SLOT_COUNT;
	private static final int PLAYER_START = MACHINE_SLOTS;
	private static final int HOTBAR_START = PLAYER_START + 27;
	private static final int PLAYER_END = HOTBAR_START + 9;

	private final class_1263 container;
	private final class_3913 data;

	/** Client side: the real contents arrive through the menu sync. */
	public FoundryMenu(int containerId, class_1661 playerInventory) {
		this(containerId, playerInventory, new class_1277(MACHINE_SLOTS), new class_3919(FoundryControllerBlockEntity.DATA_COUNT));
	}

	public FoundryMenu(int containerId, class_1661 playerInventory, class_1263 container, class_3913 data) {
		super(ModMenus.FOUNDRY, containerId);
		method_17359(container, MACHINE_SLOTS);
		method_17361(data, FoundryControllerBlockEntity.DATA_COUNT);
		this.container = container;
		this.data = data;
		container.method_5435(playerInventory.field_7546);

		this.method_7621(new InputSlot(container, FoundryControllerBlockEntity.SLOT_ROCK, ROCK_X, ROCK_Y));
		this.method_7621(new InputSlot(container, FoundryControllerBlockEntity.SLOT_SOUL, SOUL_X, SOUL_Y));
		this.method_7621(new InputSlot(container, FoundryControllerBlockEntity.SLOT_FUEL, FUEL_X, FUEL_Y));
		this.method_7621(new ResultSlot(container, FoundryControllerBlockEntity.SLOT_OUTPUT, OUTPUT_X, OUTPUT_Y));
		this.method_7621(new ResultSlot(container, FoundryControllerBlockEntity.SLOT_BYPRODUCT, BYPRODUCT_X, BYPRODUCT_Y));

		for (int row = 0; row < 3; row++) {
			for (int column = 0; column < 9; column++) {
				this.method_7621(new class_1735(playerInventory, column + row * 9 + 9, INVENTORY_X + column * 18, INVENTORY_Y + row * 18));
			}
		}

		for (int column = 0; column < 9; column++) {
			this.method_7621(new class_1735(playerInventory, column, INVENTORY_X + column * 18, HOTBAR_Y));
		}

		this.method_17360(data);
	}

	@Override
	public boolean method_7597(class_1657 player) {
		return container.method_5443(player);
	}

	@Override
	public void method_7595(class_1657 player) {
		super.method_7595(player);
		container.method_5432(player);
	}

	@Override
	public class_1799 method_7601(class_1657 player, int index) {
		class_1735 slot = this.field_7761.get(index);

		if (!slot.method_7681()) {
			return class_1799.field_8037;
		}

		class_1799 stack = slot.method_7677();
		class_1799 original = stack.method_7972();

		if (index < MACHINE_SLOTS) {
			// Machine -> player, filling the hotbar last.
			if (!this.method_7616(stack, PLAYER_START, PLAYER_END, true)) {
				return class_1799.field_8037;
			}

			slot.method_7670(stack, original);
		} else {
			int target = targetSlotFor(stack);

			if (target >= 0) {
				if (!this.method_7616(stack, target, target + 1, false)) {
					return class_1799.field_8037;
				}
			} else if (index < HOTBAR_START) {
				if (!this.method_7616(stack, HOTBAR_START, PLAYER_END, false)) {
					return class_1799.field_8037;
				}
			} else if (!this.method_7616(stack, PLAYER_START, HOTBAR_START, false)) {
				return class_1799.field_8037;
			}
		}

		if (stack.method_7960()) {
			slot.method_53512(class_1799.field_8037);
		} else {
			slot.method_7668();
		}

		if (stack.method_7947() == original.method_7947()) {
			return class_1799.field_8037;
		}

		slot.method_7667(player, stack);
		return original;
	}

	private static int targetSlotFor(class_1799 stack) {
		for (int slot = FoundryControllerBlockEntity.SLOT_ROCK; slot <= FoundryControllerBlockEntity.SLOT_FUEL; slot++) {
			if (FoundryControllerBlockEntity.isValidForSlot(slot, stack)) {
				return slot;
			}
		}

		return -1;
	}

	// ------------------------------------------------------------------ synced gauges

	/** Heat as a fraction of the maximum, 0..1000. */
	public int heatPermille() {
		return data.method_17390(FoundryControllerBlockEntity.DATA_HEAT_PERMILLE);
	}

	/** Working heat as a fraction of the maximum, 0..1000. */
	public int workHeatPermille() {
		return data.method_17390(FoundryControllerBlockEntity.DATA_WORK_HEAT_PERMILLE);
	}

	public int temperature() {
		return data.method_17390(FoundryControllerBlockEntity.DATA_TEMPERATURE);
	}

	public int burnPermille() {
		return data.method_17390(FoundryControllerBlockEntity.DATA_BURN_PERMILLE);
	}

	public int progressPermille() {
		return data.method_17390(FoundryControllerBlockEntity.DATA_PROGRESS_PERMILLE);
	}

	public int windowCycle() {
		return data.method_17390(FoundryControllerBlockEntity.DATA_WINDOW_CYCLE);
	}

	public int windowSize() {
		return data.method_17390(FoundryControllerBlockEntity.DATA_WINDOW_SIZE);
	}

	public FoundryCore.Status status() {
		return FoundryCore.Status.byOrdinal(data.method_17390(FoundryControllerBlockEntity.DATA_STATUS));
	}

	public boolean windowScrapFound() {
		return data.method_17390(FoundryControllerBlockEntity.DATA_WINDOW_SCRAP_FOUND) != 0;
	}

	public int totalScraps() {
		return (data.method_17390(FoundryControllerBlockEntity.DATA_TOTAL_SCRAPS_HIGH) << 15) | data.method_17390(FoundryControllerBlockEntity.DATA_TOTAL_SCRAPS_LOW);
	}

	public int activeMinutes() {
		return (data.method_17390(FoundryControllerBlockEntity.DATA_ACTIVE_MINUTES_HIGH) << 15) | data.method_17390(FoundryControllerBlockEntity.DATA_ACTIVE_MINUTES_LOW);
	}

	// ------------------------------------------------------------------ slots

	/** Accepts only what the machine slot behind it accepts. */
	private static final class InputSlot extends class_1735 {
		private InputSlot(class_1263 container, int slot, int x, int y) {
			super(container, slot, x, y);
		}

		@Override
		public boolean method_7680(class_1799 stack) {
			return FoundryControllerBlockEntity.isValidForSlot(this.method_34266(), stack);
		}
	}

	/** Take-only. */
	private static final class ResultSlot extends class_1735 {
		private ResultSlot(class_1263 container, int slot, int x, int y) {
			super(container, slot, x, y);
		}

		@Override
		public boolean method_7680(class_1799 stack) {
			return false;
		}
	}
}
