package dev.ancientfoundry.multiblock;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import dev.ancientfoundry.block.FoundryControllerBlock;
import dev.ancientfoundry.registry.ModBlocks;
import org.jetbrains.annotations.Nullable;

/**
 * Shape of the Ancient Foundry: 5 wide, 5 deep, 4 tall, with the controller in the middle of the
 * front wall, one block above the base.
 *
 * <p>Local coordinates are relative to the controller: {@code dx} runs sideways (-2..2), {@code dy}
 * upwards (-1..2) and {@code dz} into the structure, away from the controller's face (0..4).
 *
 * <pre>
 * dy = -1 (base)    dy = 0            dy = 1            dy = 2 (roof)
 * F F F F F         F W W W F         F W W W F         F F F F F
 * F M M M F         W L L L W         W L L L W         F W W W F
 * F M M M F         W L K L W         W L L L W         F W V W F
 * F M M M F         W L L L W         W L L L W         F W W W F
 * F F F F F         F W C W F         F W W W F         F F F F F
 *      front             front             front             front
 * </pre>
 * F = frame (casing only), W = wall (casing, glass or a hatch), M = magma block, L = lava source,
 * K = ancient core, V = vent (needs air above), C = controller.
 */
public final class FoundryStructure {
	public static final int HALF_WIDTH = 2;
	public static final int DEPTH = 5;
	public static final int MIN_Y = -1;
	public static final int MAX_Y = 2;

	/** What a position of the structure must hold. */
	public enum Part {
		FRAME, WALL, MAGMA, LAVA, CORE, VENT, CONTROLLER, AIR
	}

	/**
	 * Outcome of a structure check.
	 *
	 * @param formed        true when every block is in place
	 * @param inputHatches  input hatches found in the walls (only when formed)
	 * @param outputHatches output hatches found in the walls (only when formed)
	 * @param vent          position of the vent (only when formed)
	 * @param errorPos      first wrong position, scanning from the base up (only when not formed)
	 * @param errorPart     what that position should hold
	 * @param errorLayer    layer of the first wrong position, 1 = base .. 4 = roof, 5 = above the vent
	 */
	public record Result(boolean formed, List<class_2338> inputHatches, List<class_2338> outputHatches,
			@Nullable class_2338 vent, @Nullable class_2338 errorPos, @Nullable Part errorPart, int errorLayer) {
	}

	private FoundryStructure() {
	}

	/** What belongs at a local position; only valid inside the 5x4x5 box. */
	public static Part partAt(int dx, int dy, int dz) {
		boolean sideEdge = Math.abs(dx) == HALF_WIDTH;
		boolean depthEdge = dz == 0 || dz == DEPTH - 1;
		boolean inner = !sideEdge && !depthEdge;

		if (dy == MIN_Y) {
			return inner ? Part.MAGMA : Part.FRAME;
		}

		if (dy == MAX_Y) {
			if (!inner) {
				return Part.FRAME;
			}

			return dx == 0 && dz == 2 ? Part.VENT : Part.WALL;
		}

		// The two chamber layers.
		if (inner) {
			return dy == 0 && dx == 0 && dz == 2 ? Part.CORE : Part.LAVA;
		}

		if (sideEdge && depthEdge) {
			return Part.FRAME;
		}

		return dy == 0 && dx == 0 && dz == 0 ? Part.CONTROLLER : Part.WALL;
	}

	/** Converts a local position to a world position for a controller facing {@code facing}. */
	public static class_2338 toWorld(class_2338 controller, class_2350 facing, int dx, int dy, int dz) {
		class_2350 back = facing.method_10153();
		class_2350 side = facing.method_10160();
		return controller.method_10079(back, dz).method_10079(side, dx).method_10086(dy);
	}

	/** True when every chunk the structure touches is loaded, so checking it will not load chunks. */
	public static boolean isAreaLoaded(class_1937 level, class_2338 controller, class_2350 facing) {
		return level.method_8477(toWorld(controller, facing, -HALF_WIDTH, 0, 0))
				&& level.method_8477(toWorld(controller, facing, HALF_WIDTH, 0, 0))
				&& level.method_8477(toWorld(controller, facing, -HALF_WIDTH, 0, DEPTH - 1))
				&& level.method_8477(toWorld(controller, facing, HALF_WIDTH, 0, DEPTH - 1));
	}

	public static boolean matches(Part part, class_2680 state) {
		return switch (part) {
			case FRAME -> state.method_27852(ModBlocks.FOUNDRY_CASING);
			case WALL -> state.method_27852(ModBlocks.FOUNDRY_CASING) || state.method_27852(ModBlocks.FOUNDRY_GLASS)
					|| state.method_27852(ModBlocks.FOUNDRY_INPUT_HATCH) || state.method_27852(ModBlocks.FOUNDRY_OUTPUT_HATCH);
			case MAGMA -> state.method_27852(class_2246.field_10092);
			case LAVA -> state.method_27852(class_2246.field_10164) && state.method_26227().method_15771();
			case CORE -> state.method_27852(ModBlocks.ANCIENT_CORE);
			case VENT -> state.method_27852(ModBlocks.FOUNDRY_VENT);
			case CONTROLLER -> state.method_27852(ModBlocks.FOUNDRY_CONTROLLER);
			case AIR -> state.method_26215();
		};
	}

	/** Checks the whole structure, base first, and reports the first wrong block if there is one. */
	public static Result validate(class_1922 level, class_2338 controller, class_2350 facing) {
		List<class_2338> inputs = new ArrayList<>();
		List<class_2338> outputs = new ArrayList<>();
		class_2338 vent = null;

		for (int dy = MIN_Y; dy <= MAX_Y; dy++) {
			for (int dz = 0; dz < DEPTH; dz++) {
				for (int dx = -HALF_WIDTH; dx <= HALF_WIDTH; dx++) {
					Part part = partAt(dx, dy, dz);

					if (part == Part.CONTROLLER) {
						continue;
					}

					class_2338 pos = toWorld(controller, facing, dx, dy, dz);
					class_2680 state = level.method_8320(pos);

					if (!matches(part, state)) {
						return new Result(false, List.of(), List.of(), null, pos, part, dy - MIN_Y + 1);
					}

					if (part == Part.VENT) {
						vent = pos;
					} else if (state.method_27852(ModBlocks.FOUNDRY_INPUT_HATCH)) {
						inputs.add(pos);
					} else if (state.method_27852(ModBlocks.FOUNDRY_OUTPUT_HATCH)) {
						outputs.add(pos);
					}
				}
			}
		}

		class_2338 aboveVent = toWorld(controller, facing, 0, MAX_Y + 1, 2);

		if (!matches(Part.AIR, level.method_8320(aboveVent))) {
			return new Result(false, List.of(), List.of(), null, aboveVent, Part.AIR, MAX_Y - MIN_Y + 2);
		}

		return new Result(true, List.copyOf(inputs), List.copyOf(outputs), vent, null, null, 0);
	}

	/**
	 * Builds a complete foundry, controller included, with plain casing in every wall position.
	 * Used by the game tests; handy for creative showcases too.
	 */
	public static void place(class_1937 level, class_2338 controller, class_2350 facing) {
		for (int dy = MIN_Y; dy <= MAX_Y; dy++) {
			for (int dz = 0; dz < DEPTH; dz++) {
				for (int dx = -HALF_WIDTH; dx <= HALF_WIDTH; dx++) {
					class_2338 pos = toWorld(controller, facing, dx, dy, dz);
					class_2680 state = switch (partAt(dx, dy, dz)) {
						case FRAME, WALL -> ModBlocks.FOUNDRY_CASING.method_9564();
						case MAGMA -> class_2246.field_10092.method_9564();
						case LAVA -> class_2246.field_10164.method_9564();
						case CORE -> ModBlocks.ANCIENT_CORE.method_9564();
						case VENT -> ModBlocks.FOUNDRY_VENT.method_9564();
						case CONTROLLER -> ModBlocks.FOUNDRY_CONTROLLER.method_9564()
								.method_11657(FoundryControllerBlock.FACING, facing);
						case AIR -> class_2246.field_10124.method_9564();
					};
					level.method_8652(pos, state, 3);
				}
			}
		}

		level.method_8652(toWorld(controller, facing, 0, MAX_Y + 1, 2), class_2246.field_10124.method_9564(), 3);
	}
}
